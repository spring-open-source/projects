<h1>facecar</h1>

Face following RC car with Arduino + USB Host Shield + Android 

You can read further information from this blog <a href="http://shazsterblog.blogspot.com/2014/01/face-following-rc-car-using-android.html">link</a>
