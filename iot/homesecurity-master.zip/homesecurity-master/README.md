Home Security Service using Telegram
====================================

For more information visit <a href="http://shazsterblog.blogspot.com/2016/03/home-security-using-raspberry-pi-web.html">post</a>

Schematics
----------

<img src="HomeSecurity_schematics.png"/>

Setup
-----

<img src="setup.jpg"/>

Output
------

<img src="image.jpg"/>

