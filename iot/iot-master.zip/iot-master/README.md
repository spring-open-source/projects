iot
===

IoT with MQTT + Apache Kafka (Arduino + Raspberry Pi)

You can read more on this project in this blog <a href="http://shazsterblog.blogspot.com/2014/12/iot-with-mqtt-apache-kafka-arduino.html">post</a>
