java -classpath ../target/kafka-mqtt-bridge-0.0.1-SNAPSHOT.jar com.github.kafka.mqtt.bridge.MqttConsumerToKafkaProducer
