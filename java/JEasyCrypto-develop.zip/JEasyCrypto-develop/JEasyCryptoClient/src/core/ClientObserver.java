package core;

public interface ClientObserver {
	public void handleResponse(String response);
}