package gui;

public interface SceneManager {
    public void handleSceneClose(int id, Object obj);
}