module license3j {
    requires bcpg.jdk15on;
    requires bcprov.jdk15on;
    exports com.javax0.license3j.licensor;
    exports com.javax0.license3j;
}