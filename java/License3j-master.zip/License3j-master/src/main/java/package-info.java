/**
 * This package contains the License3j class that contains a
 * public static main method to start license geneartion. This class
 * is in the default package to ease the execution of the licensor
 * from the command line and let you avoid write long package names
 * on the command line.
 */
