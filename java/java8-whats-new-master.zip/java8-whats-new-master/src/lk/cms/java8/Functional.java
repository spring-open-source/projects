package lk.cms.java8;

/**
 * 
 * @author Shazin
 *
 */
@FunctionalInterface
public interface Functional {

	String greet(String name);
}
