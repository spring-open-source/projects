package lk.cms.java8;

/**
 * 
 * @author Shazin
 *
 */
@FunctionalInterface
public interface SingleAbstractMethod {
	
	void process(String s) throws Exception;

}
