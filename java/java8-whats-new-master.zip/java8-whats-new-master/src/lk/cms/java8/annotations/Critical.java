package lk.cms.java8.annotations;

/**
 * 
 * @author Shazin
 *
 */
public @interface Critical {

}
