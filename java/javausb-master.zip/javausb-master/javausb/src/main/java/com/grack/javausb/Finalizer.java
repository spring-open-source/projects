package com.grack.javausb;

interface Finalizer {
	void cleanup();
}
