package com.grack.javausb;

public enum USBEndpointDirection {
	IN, OUT
}
