package com.grack.javausb;

public enum USBTransferType {
	CONTROL, ISOCHRONOUS, BULK, INTERRUPT
}
