package com.github.shazin.ms.accountreg;

public class AccountReceiver {

	public void receiveMessage(String message) {
		System.out.println("Account Registeration Request Received : "+message);		
	}
}
