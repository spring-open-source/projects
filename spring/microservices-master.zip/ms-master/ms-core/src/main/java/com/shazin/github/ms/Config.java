package com.shazin.github.ms;

public class Config {
	
	public final static String USER_QUEUE_NAME = "ms-user";
	public final static String USER_EXCHANGE_NAME = "ms-user-exchange";
	
	public final static String ACCOUNT_QUEUE_NAME = "ms-account";
	public final static String ACCOUNT_EXCHANGE_NAME = "ms-account-exchange";
	
}
