# reactiveapp
Spring Boot App Build Using Reactive Programming

This is a small app developed to understand reactive programming on Spring Boot.
