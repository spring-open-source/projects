# spring-events-test
Project Developed to Showcase Spring Events based Publisher and Subscriber
