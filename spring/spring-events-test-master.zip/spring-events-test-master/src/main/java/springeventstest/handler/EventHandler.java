package springeventstest.handler;

import org.springframework.stereotype.Component;

@Component
public class EventHandler extends AbstractEventHandler {

}
