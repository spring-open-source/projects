package springeventstest.service;

public interface AuthorityService {

	
}
