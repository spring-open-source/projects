
insert into users values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546013', 0, 'test@test.com', 650, 'xpto', 'test123');

insert into meals values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546000', 0, 1000, '2015-01-01', '1 - Mitraillette', '12:00', 1);

insert into meals values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546001', 0, 2000, '2015-01-01', '1 - Eggplant Parmesan', '19:00', 1);

insert into meals values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546002', 0, 1000, '2015-01-02', '2 -  Chickpea with roasted cauliflower', '12:00', 1);

insert into meals values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546003', 0, 2000, '2015-01-02', '2 - Chicken Stew with Turnips & Mushrooms', '19:00', 1);

insert into meals values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546004', 0, 1000, '2015-01-03', '3 - Rosemary Lentils & Greens on Toasted Bread', '12:00', 1);

insert into meals values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546005', 0, 2000, '2015-01-03', '3 - Salmon Cakes with Olives, Lemon & Dill', '19:00', 1);

insert into meals values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546006', 0, 1000, '2015-01-04', '4 - Cowboy Beef & Bean Chili', '12:00', 1);

insert into meals values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546007', 0, 2000, '2015-01-04', '4 -  Duck Chiles Rellenos', '19:00', 1);

insert into meals values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546008', 0, 1000, '2015-01-05', '5 - Brussels Sprout & Potato Hash', '12:00', 1);

insert into meals values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546009', 0, 2000, '2015-01-05', '5 -  Creamy Green Chile Chicken Soup', '19:00', 1);

insert into meals values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546010', 0, 1000, '2015-01-06', '6 -  Duck Chiles Rellenos', '12:00', 1);

insert into meals values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546011', 0, 2000, '2015-01-06', '6 -  Apricot-Chile Glazed Salmon', '19:00', 1);

insert into meals values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546012', 0, 1000, '2015-01-07', '7 -  Creamy Mustard Chicken', '12:00', 1);

insert into meals values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546013', 0, 2000, '2015-01-07', '7 -   Grape Chutney', '19:00', 1);

insert into meals values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546014', 0, 1000, '2015-01-08', '8 -  Broccoli Rabe', '12:00', 1);

insert into meals values(nextval ('hibernate_sequence'), 'de305d54-75b4-431b-adb2-eb6b9e546015', 0, 1000, '2015-01-08', '8 -  Moules Frites', '19:00', 1);






