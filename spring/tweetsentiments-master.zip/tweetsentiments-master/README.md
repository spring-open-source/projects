# tweetsentiments
Simple Twitter Sentiment Notification System with ESP8266 + Arduino

Please visit the blog <a href="http://shazsterblog.blogspot.com/2015/04/simple-twitter-sentiment-notification.html">post</a> for more information.
