package com.quickserverlab.quickcached.client;

public enum CASResponse {
	OK, NOT_FOUND, EXISTS, ERROR, NOT_STORED;
}
