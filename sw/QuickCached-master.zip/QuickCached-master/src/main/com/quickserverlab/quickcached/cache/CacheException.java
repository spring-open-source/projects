package com.quickserverlab.quickcached.cache;

/**
 *
 * @author akshath
 */
public class CacheException extends Exception {
	public CacheException() {
		super();
	}
	
	public CacheException(String msg) {
		super(msg);
	}
}
